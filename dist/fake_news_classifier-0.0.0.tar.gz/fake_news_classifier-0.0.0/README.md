<<<<<<< HEAD
# fake-news-model
Deployment of fake news classifier
=======
fake_news_classifier
>>>>>>> r0
