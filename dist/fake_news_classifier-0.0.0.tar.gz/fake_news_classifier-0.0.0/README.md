# fake-news-model
Deployment of fake news classifier
